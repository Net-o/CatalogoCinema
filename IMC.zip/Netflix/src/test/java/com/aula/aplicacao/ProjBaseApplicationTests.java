package com.aula.aplicacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
