package com.aula.aplicacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjBaseApplication.class, args);
	}

}
